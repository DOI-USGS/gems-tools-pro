USGS Symbols2.style

is an ESRI .style file that combines the GSC implementation of the FGDC Digital Cartographic Standard for Geologic Map Symbolization (FGDC-STD-013-2006), developed by Vic Dohar and Dave Everett of the Geological Survey of Canada, with the WPGCMYK (Western Publications Group CMYK) fill colors that are included in the 'USGS Symbols' style distributed with ArcGIS. 

To use the GSC-FGDC line and marker symbols you must install (requires admin privileges) the FGDCGeoSym fonts included in this zip file.

